﻿using System;
using System.Diagnostics;
using System.ComponentModel;

namespace MyProcessSample
{
    class MyProcess
    {
        public static void Main()
        {
            try
            {
                Process scriptProc = new Process();
                scriptProc.StartInfo.FileName = @"cscript"; 
                scriptProc.StartInfo.WorkingDirectory = @"C:\\Users\\junk\\Desktop";
                scriptProc.StartInfo.Arguments ="//B //Nologo script.vbs";
                scriptProc.StartInfo.WindowStyle = ProcessWindowStyle.Hidden; //prevents console window from popping out
                scriptProc.Start();
                scriptProc.WaitForExit(); //(Optional)
                scriptProc.Close();
            
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
    }
}



//@" C:\\Users\\junk\\Desktop\\script.vbs"

